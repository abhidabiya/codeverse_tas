const Event = require('../models/event');

// Create
exports.createEvent = async (req, res, next) => {
  try {
    const { title, description, price } = req.body;
    const item = await Event.create({ title, description, price });
    res.status(201).json(item);
  } catch (err) { next(err); }
};

// Read all
exports.getAllEvent = async (req, res, next) => {
  try {
    const items = await Event.find().sort('-createdAt');
    res.json(items);
  } catch (err) { next(err); }
};

// Read single
exports.getSingleEvent = async (req, res, next) => {
  try {
    const item = await Event.findById(req.params.id);
    if (!item) return res.status(404).json({ message: 'Event not found' });
    res.json(item);
  } catch (err) { next(err); }
};

// Update
exports.updateEvent = async (req, res, next) => {
  try {
    const event = await Event.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!event) return res.status(404).json({ message: 'Event not found' });
    res.json(event);
  } catch (err) { next(err); }
};

// Delete
exports.deleteItem = async (req, res, next) => {
  try {
    const event = await Event.findByIdAndDelete(req.params.id);
    if (!event) return res.status(404).json({ message: 'Event not found' });
    res.json({ message: 'Event removed' });
  } catch (err) { next(err); }
};
