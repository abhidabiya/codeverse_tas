const Booking = require('../models/Booking.js'); 
const Event = require('../models/event.js'); 


const getAnalytics = (bookings, events) => {
   
    const totalEvents = events.length;

    let totalTicketsSold = 0;
    let totalRevenue = 0;
    const ticketsPerEvent = {};
    bookings.forEach(booking => {
        totalTicketsSold += booking.tickets || 0;
        totalRevenue += booking.totalPrice || 0;

        if (booking.event && booking.event._id) { 
            const eventId = booking.event._id.toString();
            ticketsPerEvent[eventId] = (ticketsPerEvent[eventId] || 0) + (booking.tickets || 0);
        }
    });

   
    let topSellingEvent = null;
    let maxTicketsSold = 0;

    for (const eventId in ticketsPerEvent) {
        if (ticketsPerEvent[eventId] > maxTicketsSold) {
            maxTicketsSold = ticketsPerEvent[eventId];
           
            topSellingEvent = events.find(e => e._id.toString() === eventId);
        }
    }

    return {
        totalEvents,
        totalTicketsSold,
        totalRevenue,
        topSellingEvent: topSellingEvent ? {
            _id: topSellingEvent._id,
            name: topSellingEvent.name, 
            ticketsSold: maxTicketsSold
        } : null
    };
};

// Get Analytics Reports
exports.getBookingreport = async (req, res, next) => {
    try {
        
        const [allBookings, allEvents] = await Promise.all([
            Booking.find().sort('-createdAt'),
            Event.find().sort('-createdAt')
        ]);

        if (!allBookings || allBookings.length === 0) {
          
            return res.status(200).json({ message: 'No bookings found, analytics are empty.', analytics: {
                totalEvents: allEvents.length,
                totalTicketsSold: 0,
                totalRevenue: 0,
                topSellingEvent: null
            }});
        }
        
        
        const analyticsData = getAnalytics(allBookings, allEvents);

        
        res.status(200).json(analyticsData);

    } catch (err) {
      
        next(err);
    }
};
