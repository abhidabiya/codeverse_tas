const booking = require('../models/Booking.js');

// Bookings creation
exports.createBooking = async (req, res, next) => {

//    res.status(201).json({ 
//     msg: "Booking created successfully",
//     key: "Checkpoint reached"
//    });

    try {
    const { userid, role, eventid, qty } = req.body;
    const bokiing = await booking.create({ userid, role, eventid, qty });

    pushNotification(userid, "Bookign is Created Successfully");

    res.status(201).json({ massage: "Booking created successfully", booking });
  } catch (err) { next(err); }
};



const pushNotification = (userId, message) => {

  io.on('connection', (socket) => {

    socket.on("New Booking is Created", () => {
    
      socket.join(userData.id);
    
    }
  )
})

  io.to(userId).emit('notification', { message });
}