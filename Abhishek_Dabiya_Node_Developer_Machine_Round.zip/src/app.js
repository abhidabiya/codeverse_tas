require('dotenv').config();
require('express-async-errors');
const express = require('express');
const cors = require('cors');
const cookieParser = require('cookie-parser');

const authRoutes = require('./routes/authRoutes');
const EventRoutes = require('./routes/eventRoutes');
const BookingRoutes = require('./routes/bookingRoutes');
const analyticalReport = require('./routes/analyticalReport');
const errorHandler = require('./middlewares/errorMiddleware');

const app = express();

app.use(cors());
app.use(express.json());
app.use(cookieParser());
app.use(express.urlencoded({ extended: true }));

// routes
app.use('/api/auth', authRoutes);
app.use('/api/event', EventRoutes);
app.use('/api/booking', BookingRoutes);
app.use('/api/report', analyticalReport);

// Check
app.get('/', (req, res) => res.send('API is running'));


app.use(errorHandler);

module.exports = app;
