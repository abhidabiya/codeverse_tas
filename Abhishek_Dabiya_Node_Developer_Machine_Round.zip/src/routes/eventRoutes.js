const express = require('express');
const router = express.Router();
const {
  createEvent,
  getAllEvent,
  getSingleEvent,
  updateEvent,
  deleteItem
} = require('../controllers/eventController.js');

const protect = require('../middlewares/authMiddleware');

router.get('/', getAllEvent);

router.post('/', protect, createEvent);

router.get('/:id', getSingleEvent);

router.put('/:id', protect, updateEvent);

router.delete('/:id', protect, deleteItem);

module.exports = router;









