const express = require('express');
const router = express.Router();
const {
    createBooking
} = require('../controllers/bookingController.js');

const protect = require('../middlewares/authMiddleware');

router.post('/book_event', protect, createBooking);


module.exports = router;









