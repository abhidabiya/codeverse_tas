const express = require('express');
const router = express.Router();
const protect = require('../middlewares/authMiddleware');
const { getBookingreport } = require('../controllers/analyticReport.js');

router.get('/analytical_report', protect, getBookingreport);

module.exports = router;
