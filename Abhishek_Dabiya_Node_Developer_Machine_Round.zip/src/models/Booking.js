const mongoose = require('mongoose');

const BookingSchema = new mongoose.Schema({
  userid: { type: String, required: true, },
  role: { type: String, required: true },
  eventid: { type: String, required: true, },
  qty: { type: Number, required: true },
}, { timestamps: true });

module.exports = mongoose.model('booking', BookingSchema);
